"""Vercel serverless entry point for World Monitor."""
import os
import sys
from pathlib import Path

os.environ["VERCEL"] = "1"
sys.path.insert(0, str(Path(__file__).parent.parent))

from app.main import app
