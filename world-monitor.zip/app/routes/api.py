"""REST API endpoints — JSON responses for HTMX and external consumers."""

import csv
import io
import json
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.services import indicator_service as svc

router = APIRouter(prefix="/api")


@router.get("/indicators")
def list_indicators(
    category: str | None = Query(None),
    active_only: bool = Query(True),
    db: Session = Depends(get_db),
):
    """List all indicators, optionally filtered by category."""
    if category:
        indicators = svc.get_indicators_by_category(db, category)
    else:
        indicators = svc.get_all_indicators(db, active_only=active_only)
    return {
        "count": len(indicators),
        "indicators": [
            {
                "id": i.id,
                "category": i.category,
                "name": i.name,
                "name_cn": i.name_cn,
                "unit": i.unit,
                "value": i.value,
                "previous_value": i.previous_value,
                "change_pct": i.change_pct,
                "trend": i.trend,
                "importance": i.importance,
                "last_updated": i.last_updated.isoformat() if i.last_updated else None,
                "source_name": i.source_name,
            }
            for i in indicators
        ],
    }


@router.get("/indicators/{indicator_id}")
def get_indicator(indicator_id: int, db: Session = Depends(get_db)):
    """Get a single indicator with its history."""
    indicator = svc.get_indicator(db, indicator_id)
    if not indicator:
        raise HTTPException(status_code=404, detail="Indicator not found")
    history = svc.get_indicator_history(db, indicator_id)
    return {
        "id": indicator.id,
        "category": indicator.category,
        "name": indicator.name,
        "name_cn": indicator.name_cn,
        "unit": indicator.unit,
        "value": indicator.value,
        "previous_value": indicator.previous_value,
        "change_pct": indicator.change_pct,
        "trend": indicator.trend,
        "importance": indicator.importance,
        "description": indicator.description,
        "source_name": indicator.source_name,
        "source_url": indicator.source_url,
        "update_frequency": indicator.update_frequency,
        "last_updated": indicator.last_updated.isoformat() if indicator.last_updated else None,
        "history": [
            {"date": h.recorded_at.isoformat(), "value": h.value}
            for h in history
        ],
    }


@router.get("/events")
def list_events(
    min_importance: int = Query(3),
    limit: int = Query(50),
    db: Session = Depends(get_db),
):
    """List signal events."""
    events = svc.get_high_energy_signals(db, min_importance=min_importance, limit=limit)
    return {
        "count": len(events),
        "events": [
            {
                "id": e.id,
                "category": e.category,
                "title": e.title,
                "title_cn": e.title_cn,
                "description": e.description,
                "importance": e.importance,
                "event_date": e.event_date.isoformat() if e.event_date else None,
                "source_name": e.source_name,
            }
            for e in events
        ],
    }


@router.get("/summary")
def dashboard_summary(db: Session = Depends(get_db)):
    """Get dashboard summary in JSON format."""
    from app.collectors.scheduler import get_collector_status
    summary = svc.get_dashboard_summary(db)
    return {
        "total_indicators": summary["total_indicators"],
        "importance_counts": summary["importance_counts"],
        "last_updated": summary["last_updated"].isoformat() if summary["last_updated"] else None,
        "signals": [
            {
                "id": e.id,
                "category": e.category,
                "title_cn": e.title_cn,
                "importance": e.importance,
            }
            for e in summary["signals"]
        ],
        "collector_status": get_collector_status(),
    }


@router.get("/chart-data")
def chart_data(db: Session = Depends(get_db)):
    """Return all indicator history data for frontend charts."""
    from app.services.indicator_service import _get_indicators_with_history
    chart_indicators = _get_indicators_with_history(db)
    return {
        "indicators": [
            {
                "name": ci["indicator"]["name_cn"],
                "unit": ci["indicator"]["unit"],
                "category": ci["indicator"]["category"],
                "history": ci["history"],
            }
            for ci in chart_indicators
        ]
    }


@router.get("/conflict-hotspots")
def conflict_hotspots():
    """Return conflict hotspot data for the world map."""
    from app.services.indicator_service import get_conflict_hotspots
    return {"hotspots": get_conflict_hotspots()}


@router.post("/collect-now")
async def collect_now():
    """Trigger all data collectors to run immediately. Returns results summary."""
    from app.collectors.scheduler import collect_all
    from app.config import COLLECTOR_ENABLED

    if not COLLECTOR_ENABLED:
        return {"status": "disabled", "message": "Collectors are disabled in config."}

    try:
        results = await collect_all()
        return {
            "status": "ok",
            "collectors": [
                {
                    "name": r.collector_name,
                    "ok": r.ok_count,
                    "skipped": r.skip_count,
                    "errors": r.error_count,
                    "error": r.error,
                }
                for r in results
            ],
            "total_updated": sum(r.ok_count for r in results),
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


@router.get("/export/csv")
def export_csv(db: Session = Depends(get_db)):
    """Export all indicators as CSV."""
    from app.services.indicator_service import get_all_indicators

    indicators = get_all_indicators(db, active_only=False)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID", "分类", "中文名", "英文名", "值", "单位", "前值", "变化率(%)", "趋势", "能量等级", "数据源", "更新时间"])

    for ind in indicators:
        writer.writerow([
            ind.id, ind.category, ind.name_cn, ind.name, ind.value, ind.unit,
            ind.previous_value, ind.change_pct, ind.trend, ind.importance,
            ind.source_name, ind.last_updated.isoformat() if ind.last_updated else "",
        ])

    output.seek(0)
    filename = f"world-monitor-export-{datetime.now(timezone.utc).strftime('%Y%m%d')}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv; charset=utf-8-sig",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@router.get("/export/json")
def export_json(db: Session = Depends(get_db)):
    """Export all indicators with history as JSON."""
    from app.services.indicator_service import get_all_indicators, get_indicator_history

    indicators = get_all_indicators(db, active_only=False)
    data = []
    for ind in indicators:
        history = get_indicator_history(db, ind.id)
        data.append({
            "id": ind.id,
            "category": ind.category,
            "name": ind.name,
            "name_cn": ind.name_cn,
            "unit": ind.unit,
            "value": ind.value,
            "previous_value": ind.previous_value,
            "change_pct": ind.change_pct,
            "trend": ind.trend,
            "importance": ind.importance,
            "description": ind.description,
            "source_name": ind.source_name,
            "source_url": ind.source_url,
            "last_updated": ind.last_updated.isoformat() if ind.last_updated else None,
            "history": [{"date": h.recorded_at.isoformat(), "value": h.value} for h in history],
        })

    filename = f"world-monitor-export-{datetime.now(timezone.utc).strftime('%Y%m%d')}.json"
    return StreamingResponse(
        iter([io.StringIO(json.dumps(data, ensure_ascii=False, indent=2)).getvalue()]),
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )
