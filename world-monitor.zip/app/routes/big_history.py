"""Big History Perspective — page and API routes."""

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import HTMLResponse
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.services import big_history_service as bhsvc

router = APIRouter()


@router.get("/big-history", response_class=HTMLResponse)
async def big_history_page(request: Request):
    """Render the Big History Perspective page."""
    db = next(get_db())
    try:
        data = bhsvc.get_big_history_page_data(db)
        return request.app.state.templates.TemplateResponse(
            "big_history.html", {"request": request, **data}
        )
    finally:
        db.close()


@router.get("/api/big-history/analogs")
def api_analogs(
    indicator_id: int = Query(..., description="Indicator ID to find analogs for"),
    top_k: int = Query(5, ge=1, le=20, description="Number of top matches to return"),
    window_size: int = Query(6, ge=3, le=20, description="Sliding window size for pattern matching"),
    db: Session = Depends(get_db),
):
    """
    Return DTW-based historical curve-shape analogs for an indicator.

    Each analog includes the matched segment, similarity score,
    and the "what happened next" future values.
    """
    analogs = bhsvc.find_analogs(db, indicator_id, query_window_size=window_size, top_k=top_k)
    return {"indicator_id": indicator_id, "analogs": analogs, "count": len(analogs)}


@router.get("/api/big-history/predictions")
def api_predictions(
    indicator_id: int = Query(..., description="Indicator ID to generate predictions for"),
    horizon_years: int = Query(5, ge=1, le=10, description="Prediction horizon in years"),
    db: Session = Depends(get_db),
):
    """
    Generate prediction corridor based on top analog matches.

    Returns central, optimistic, and pessimistic projections
    along with the underlying analog data.
    """
    predictions = bhsvc.compute_predictions(db, indicator_id, horizon_years=horizon_years)
    return predictions if predictions else {"indicator_id": indicator_id, "message": "Insufficient data"}


@router.get("/api/big-history/pulse")
def api_pulse(db: Session = Depends(get_db)):
    """Return the civilization pulse aggregate trend data."""
    return bhsvc.get_civilization_pulse(db)
