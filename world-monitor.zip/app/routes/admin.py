"""Admin routes for manual data management."""

from fastapi import APIRouter, Request, Form, Depends
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy.orm import Session

from app.models.database import get_db
from app.services import indicator_service as svc
from app.config import CATEGORIES, IMPORTANCE

router = APIRouter(prefix="/admin")


@router.get("/", response_class=HTMLResponse)
async def admin_panel(request: Request, db: Session = Depends(get_db)):
    """Admin management page."""
    indicators = svc.get_all_indicators(db, active_only=False)
    events = svc.get_all_events(db)
    return request.app.state.templates.TemplateResponse(
        "admin.html",
        {
            "request": request,
            "indicators": indicators,
            "events": events,
            "categories": CATEGORIES,
            "importance_levels": IMPORTANCE,
        },
    )


@router.post("/indicators/add")
async def add_indicator(
    request: Request,
    category: str = Form(...),
    name: str = Form(...),
    name_cn: str = Form(...),
    unit: str = Form(""),
    value: float = Form(None),
    importance: int = Form(2),
    description: str = Form(""),
    source_name: str = Form(""),
    source_url: str = Form(""),
    update_frequency: str = Form("daily"),
    db: Session = Depends(get_db),
):
    """Add a new indicator manually."""
    data = {
        "category": category,
        "name": name,
        "name_cn": name_cn,
        "unit": unit,
        "value": value,
        "importance": importance,
        "description": description,
        "source_name": source_name,
        "source_url": source_url,
        "update_frequency": update_frequency,
    }
    svc.create_indicator(db, data)
    return RedirectResponse(url="/admin", status_code=303)


@router.post("/indicators/{indicator_id}/update")
async def update_indicator_value(
    indicator_id: int,
    value: float = Form(...),
    db: Session = Depends(get_db),
):
    """Quick-update an indicator's current value."""
    from datetime import datetime, timezone
    indicator = svc.get_indicator(db, indicator_id)
    if indicator:
        indicator.previous_value = indicator.value
        indicator.value = value
        if indicator.previous_value and indicator.previous_value != 0:
            indicator.change_pct = round(
                (value - indicator.previous_value) / abs(indicator.previous_value) * 100, 2
            )
        if indicator.previous_value:
            if value > indicator.previous_value:
                indicator.trend = "up"
            elif value < indicator.previous_value:
                indicator.trend = "down"
            else:
                indicator.trend = "stable"
        indicator.last_updated = datetime.now(timezone.utc)

        # Record history
        from app.models.schema import IndicatorValue
        iv = IndicatorValue(indicator_id=indicator_id, value=value)
        db.add(iv)
        db.commit()
    return RedirectResponse(url="/admin", status_code=303)


@router.post("/events/add")
async def add_event(
    request: Request,
    category: str = Form(...),
    title_cn: str = Form(...),
    description: str = Form(""),
    importance: int = Form(3),
    source_name: str = Form(""),
    db: Session = Depends(get_db),
):
    """Add a new signal event."""
    data = {
        "category": category,
        "title": title_cn,  # Use Chinese as primary for now
        "title_cn": title_cn,
        "description": description,
        "importance": importance,
        "source_name": source_name,
    }
    svc.create_event(db, data)
    return RedirectResponse(url="/admin", status_code=303)


@router.post("/indicators/{indicator_id}/delete")
async def delete_indicator(indicator_id: int, db: Session = Depends(get_db)):
    """Soft-delete an indicator (set is_active=False)."""
    indicator = svc.get_indicator(db, indicator_id)
    if indicator:
        indicator.is_active = False
        db.commit()
    return RedirectResponse(url="/admin", status_code=303)


@router.post("/events/{event_id}/delete")
async def delete_event(event_id: int, db: Session = Depends(get_db)):
    """Hard-delete a signal event."""
    from app.models.schema import SignalEvent
    event = db.query(SignalEvent).filter(SignalEvent.id == event_id).first()
    if event:
        db.delete(event)
        db.commit()
    return RedirectResponse(url="/admin", status_code=303)
