"""Business logic layer for indicators and events."""

from sqlalchemy import desc, func
from sqlalchemy.orm import Session

from app.config import CATEGORIES, IMPORTANCE
from app.models.schema import Indicator, IndicatorValue, SignalEvent


def get_all_indicators(db: Session, active_only: bool = True):
    """Return all indicators, optionally filtered to active."""
    q = db.query(Indicator)
    if active_only:
        q = q.filter(Indicator.is_active == True)
    return q.order_by(Indicator.importance.desc(), Indicator.category).all()


def get_indicators_by_category(db: Session, category: str):
    """Return active indicators for a given category."""
    return (
        db.query(Indicator)
        .filter(Indicator.category == category, Indicator.is_active == True)
        .order_by(Indicator.importance.desc())
        .all()
    )


def get_indicator(db: Session, indicator_id: int):
    """Return a single indicator by ID."""
    return db.query(Indicator).filter(Indicator.id == indicator_id).first()


def get_indicator_history(db: Session, indicator_id: int, limit: int = 100):
    """Return historical values for an indicator."""
    return (
        db.query(IndicatorValue)
        .filter(IndicatorValue.indicator_id == indicator_id)
        .order_by(IndicatorValue.recorded_at.asc())
        .limit(limit)
        .all()
    )


def get_high_energy_signals(db: Session, min_importance: int = 4, limit: int = 10):
    """Return high-importance signal events."""
    return (
        db.query(SignalEvent)
        .filter(SignalEvent.importance >= min_importance)
        .order_by(desc(SignalEvent.importance), desc(SignalEvent.event_date))
        .limit(limit)
        .all()
    )


def get_all_events(db: Session, limit: int = 50):
    """Return recent signal events."""
    return (
        db.query(SignalEvent)
        .order_by(desc(SignalEvent.event_date))
        .limit(limit)
        .all()
    )


def get_dashboard_summary(db: Session):
    """Assemble the complete dashboard data context."""
    indicators = get_all_indicators(db)
    signals = get_high_energy_signals(db, min_importance=3, limit=8)

    # Build a lookup: indicator_id → recent history points (for sparklines)
    sparkline_map = _get_sparkline_data(db)

    # Group indicators by category, attaching sparkline to each
    by_category = {}
    for cat_slug, cat_info in CATEGORIES.items():
        cat_indicators = [i for i in indicators if i.category == cat_slug]
        # Attach sparkline data to each indicator object dynamically
        for ind in cat_indicators:
            ind.sparkline = sparkline_map.get(ind.id, [])
        by_category[cat_slug] = {
            "info": cat_info,
            "indicators": cat_indicators,
        }

    # Importance counts
    importance_counts = {}
    for level in range(1, 6):
        importance_counts[level] = len([i for i in indicators if i.importance == level])

    # All indicators with full history (for the trend chart grid)
    indicators_with_history = _get_indicators_with_history(db)

    return {
        "by_category": by_category,
        "signals": signals,
        "total_indicators": len(indicators),
        "importance_counts": importance_counts,
        "importance_labels": IMPORTANCE,
        "categories": CATEGORIES,
        "last_updated": max((i.last_updated for i in indicators if i.last_updated), default=None),
        "chart_indicators": indicators_with_history,
    }


def _get_sparkline_data(db: Session) -> dict:
    """Return a dict mapping indicator_id → list of (date_str, value) for the last 8 points.
    Used for inline SVG sparklines in indicator cards.
    """
    # Get all indicator IDs that have at least 2 history points
    rows = (
        db.query(IndicatorValue.indicator_id, func.count(IndicatorValue.id).label("cnt"))
        .group_by(IndicatorValue.indicator_id)
        .having(func.count(IndicatorValue.id) >= 2)
        .all()
    )

    sparkline_map = {}
    for ind_id, count in rows:
        history = (
            db.query(IndicatorValue)
            .filter(IndicatorValue.indicator_id == ind_id)
            .order_by(IndicatorValue.recorded_at.asc())
            .all()
        )
        # Take last 8 points for the sparkline
        points = history[-8:]
        sparkline_map[ind_id] = [
            {"date": h.recorded_at.strftime("%Y"), "value": h.value}
            for h in points
        ]
    return sparkline_map


def _get_indicators_with_history(db: Session):
    """Return ALL indicators that have historical data (≥3 points) for charting."""
    indicator_ids = (
        db.query(IndicatorValue.indicator_id, func.count(IndicatorValue.id).label("cnt"))
        .group_by(IndicatorValue.indicator_id)
        .having(func.count(IndicatorValue.id) >= 3)
        .order_by(func.count(IndicatorValue.id).desc())
        .all()
    )

    result = []
    for ind_id, count in indicator_ids:
        indicator = db.query(Indicator).filter(Indicator.id == ind_id).first()
        if indicator:
            history = get_indicator_history(db, ind_id)
            result.append({
                "indicator": {
                    "id": indicator.id,
                    "name": indicator.name,
                    "name_cn": indicator.name_cn,
                    "unit": indicator.unit,
                    "category": indicator.category,
                    "value": indicator.value,
                    "trend": indicator.trend,
                    "importance": indicator.importance,
                    "source_name": indicator.source_name,
                },
                "history": [
                    {"date": h.recorded_at.isoformat(), "value": h.value}
                    for h in history
                ],
            })
    return result


def create_indicator(db: Session, data: dict):
    """Create a new indicator."""
    indicator = Indicator(**data)
    db.add(indicator)
    db.commit()
    db.refresh(indicator)
    return indicator


def update_indicator(db: Session, indicator_id: int, data: dict):
    """Update an existing indicator."""
    indicator = get_indicator(db, indicator_id)
    if not indicator:
        return None
    for key, value in data.items():
        if hasattr(indicator, key):
            setattr(indicator, key, value)
    db.commit()
    db.refresh(indicator)
    return indicator


def get_conflict_hotspots() -> list[dict]:
    """Return static conflict hotspot data for the world map."""
    from data.seed_data import CONFLICT_HOTSPOTS
    return CONFLICT_HOTSPOTS


def create_event(db: Session, data: dict):
    """Create a new signal event."""
    event = SignalEvent(**data)
    db.add(event)
    db.commit()
    db.refresh(event)
    return event
