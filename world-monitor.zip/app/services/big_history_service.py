"""
Big History Perspective — time-series analog discovery engine.

Uses Dynamic Time Warping (DTW) with Sakoe-Chiba band to find
historical curve-shape analogs across all World Monitor indicators.
Generates prediction corridors based on "what happened next" in
the matched historical segments.

Pure Python — zero new dependencies. Data volumes are small enough
(28 indicators × ~15 points ≈ 400 data points) for O(N²) DTW.
"""

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy.orm import Session

from app.config import CATEGORIES, IMPORTANCE
from app.models.schema import Indicator, IndicatorValue

logger = logging.getLogger("world-monitor.big-history")


# ═══════════════════════════════════════════════════════════════════
# Known Historical Analogs (curated pairs)
# ═══════════════════════════════════════════════════════════════════

KNOWN_ANALOGS = [
    {
        "title_cn": "大萧条 (1929) → 全球金融危机 (2008)",
        "title_en": "Great Depression 1929 → Global Financial Crisis 2008",
        "indicator_a": "S&P 500 Index",
        "period_a": "1929-1933",
        "indicator_b": "S&P 500 Index",
        "period_b": "2007-2009",
        "description_cn": "资产泡沫、信贷过度扩张、政策应对迟滞——两次危机前均出现类似的金融脆弱性积累与市场过度乐观。",
        "category": "economy",
        "importance": 5,
    },
    {
        "title_cn": "西班牙流感 (1918) → 新冠疫情 (2020)",
        "title_en": "Spanish Flu 1918 → COVID-19 2020",
        "indicator_a": "Global Population",
        "period_a": "1918-1920",
        "indicator_b": "Global Population",
        "period_b": "2020-2022",
        "description_cn": "全球大流行病的传播模式惊人相似：初期轻视→爆发恐慌→社会行为改变→长期经济与社会结构重塑。",
        "category": "livelihood",
        "importance": 5,
    },
    {
        "title_cn": "1970年代滞胀 → 2020年代通胀周期",
        "title_en": "1970s Stagflation → 2020s Inflation Cycle",
        "indicator_a": "US CPI YoY",
        "period_a": "1973-1982",
        "indicator_b": "US CPI YoY",
        "period_b": "2021-2026",
        "description_cn": "供给冲击（石油危机 vs 供应链断裂+俄乌战争）、宽松货币滞后效应、工资-物价螺旋风险——通胀结构高度相似。",
        "category": "economy",
        "importance": 5,
    },
    {
        "title_cn": "冷战核武竞赛 → 当前核现代化",
        "title_en": "Cold War Nuclear Race → Current Nuclear Modernization",
        "indicator_a": "Global Nuclear Warheads",
        "period_a": "1955-1970",
        "indicator_b": "Global Military Expenditure",
        "period_b": "2015-2026",
        "description_cn": "虽然核弹头总数在下降，但军费持续攀升和核武现代化升级的曲线形态与冷战早期的军备扩张相似。",
        "category": "military",
        "importance": 4,
    },
    {
        "title_cn": "1930年代贸易保护主义 → 当前全球贸易碎片化",
        "title_en": "1930s Protectionism → Current Trade Fragmentation",
        "indicator_a": "Trade Restrictions",
        "period_a": "1929-1939",
        "indicator_b": "Trade Restrictions",
        "period_b": "2016-2026",
        "description_cn": "关税壁垒、技术脱钩、供应链武器化——当前全球贸易限制措施的增长曲线与1930年代关税战前夕高度吻合。",
        "category": "politics",
        "importance": 5,
    },
    {
        "title_cn": "二战前夕冲突激增 → 当前全球冲突扩散",
        "title_en": "Pre-WWII Conflict Surge → Current Conflict Proliferation",
        "indicator_a": "Active Armed Conflicts",
        "period_a": "1935-1939",
        "indicator_b": "Active Armed Conflicts",
        "period_b": "2018-2026",
        "description_cn": "区域性冲突数量快速攀升、大国代理人战争增加、国际调停机制失灵——与二战前十年存在令人不安的平行。",
        "category": "politics",
        "importance": 5,
    },
    {
        "title_cn": "工业革命人口转型 → AI时代劳动力变革",
        "title_en": "Industrial Revolution Demographics → AI-Era Labor Transformation",
        "indicator_a": "Global Population",
        "period_a": "1800-1850",
        "indicator_b": "Semiconductor Market",
        "period_b": "2010-2026",
        "description_cn": "技术革命带来的生产力跃升具有相似的指数增长曲线形态，从蒸汽机到半导体再到AI。",
        "category": "technology",
        "importance": 4,
    },
    {
        "title_cn": "一战难民潮 → 当代被迫流离失所危机",
        "title_en": "WWI Refugee Crisis → Modern Displacement Crisis",
        "indicator_a": "Global Refugees",
        "period_a": "1914-1920",
        "indicator_b": "Global Refugees",
        "period_b": "2015-2026",
        "description_cn": "大规模人口被迫流离失所的曲线形态呈现周期性爆发特征，当前攀升速度与一战时期相当。",
        "category": "livelihood",
        "importance": 4,
    },
    {
        "title_cn": "互联网泡沫 → AI投资狂热",
        "title_en": "Dot-Com Bubble → AI Investment Mania",
        "indicator_a": "S&P 500 Index",
        "period_a": "1995-2000",
        "indicator_b": "Largest AI Training Compute",
        "period_b": "2020-2026",
        "description_cn": "技术投资指数级增长、估值脱离基本面、FOMO驱动资本涌入——AI算力投入曲线与互联网泡沫时期股市曲线具有相似形态。",
        "category": "technology",
        "importance": 4,
    },
    {
        "title_cn": "二战后全球化浪潮 → 当前全球化逆转",
        "title_en": "Post-WWII Globalization → Current De-globalization",
        "indicator_a": "Human Development Index",
        "period_a": "1950-1980",
        "indicator_b": "Global Peace Index",
        "period_b": "2010-2026",
        "description_cn": "HDI的持续上升与和平指数的持续恶化形成镜像——发展成果正在被冲突风险侵蚀，类似大战前的矛盾积累期。",
        "category": "composite",
        "importance": 4,
    },
]


# ═══════════════════════════════════════════════════════════════════
# Normalization Utilities
# ═══════════════════════════════════════════════════════════════════

def _normalize(values: list[float]) -> list[float]:
    """Min-max normalize to [0, 1]. Returns all 0.5 if range is zero."""
    if not values:
        return []
    vmin, vmax = min(values), max(values)
    if vmax == vmin:
        return [0.5] * len(values)
    return [(v - vmin) / (vmax - vmin) for v in values]


def _extract_normalized_series(history: list) -> tuple[list[float], list[str], float, float]:
    """
    Extract normalized values and date labels from DB history rows.

    Args:
        history: list of IndicatorValue ORM objects (with .value, .recorded_at)

    Returns:
        (normalized_values, date_labels, orig_min, orig_max)
    """
    values = [float(h.value) for h in history]
    dates = [h.recorded_at.strftime("%Y-%m-%d") for h in history]
    orig_min, orig_max = min(values), max(values)
    normed = _normalize(values)
    return normed, dates, orig_min, orig_max


# ═══════════════════════════════════════════════════════════════════
# Dynamic Time Warping (Pure Python)
# ═══════════════════════════════════════════════════════════════════

def dtw_distance(seq_a: list[float], seq_b: list[float],
                 window: int | None = None) -> float:
    """
    Compute DTW distance between two sequences with Sakoe-Chiba band.

    Args:
        seq_a, seq_b: normalized value sequences
        window: Sakoe-Chiba band width (default: max(len(a), len(b)))

    Returns:
        raw DTW cost (sum of absolute differences along optimal warp path)
    """
    n, m = len(seq_a), len(seq_b)
    if n < 2 or m < 2:
        return float("inf")

    w = window if window is not None else max(n, m)

    # Initialize cost matrix
    dtw = [[float("inf")] * (m + 1) for _ in range(n + 1)]
    dtw[0][0] = 0.0

    for i in range(1, n + 1):
        j_start = max(1, i - w)
        j_end = min(m, i + w)
        for j in range(j_start, j_end + 1):
            cost = abs(seq_a[i - 1] - seq_b[j - 1])
            dtw[i][j] = cost + min(dtw[i - 1][j], dtw[i][j - 1], dtw[i - 1][j - 1])

    return dtw[n][m]


def normalized_dtw_distance(seq_a: list[float], seq_b: list[float],
                            window: int | None = None) -> float:
    """
    Normalized DTW distance (divided by approximate path length).

    This makes distances comparable across different-length sequences.
    """
    n, m = len(seq_a), len(seq_b)
    raw = dtw_distance(seq_a, seq_b, window)
    if raw == float("inf"):
        return float("inf")
    # Path length ≈ n + m (diagonal traversal)
    return raw / (n + m)


# ═══════════════════════════════════════════════════════════════════
# Analog Discovery Engine
# ═══════════════════════════════════════════════════════════════════

def find_analogs(
    db: Session,
    indicator_id: int,
    query_window_size: int = 6,
    top_k: int = 5,
    min_history_points: int = 8,
) -> list[dict]:
    """
    Find the top-K historical curve-shape analogs for an indicator.

    Algorithm:
    1. Extract the last `query_window_size` points of the target indicator
       as the query window, normalize to [0,1].
    2. For every indicator in the database (including self), slide a
       window of the same length across its full history.
    3. Compute DTW distance between the query window and each candidate.
    4. Exclude windows overlapping the query indicator's own query zone.
    5. Return top K matches, each with their "future" segment (what
       happened after the matched window).

    Returns:
        List of dicts with keys:
        - analog_indicator_id, analog_indicator_name, analog_indicator_name_cn
        - analog_category, distance, similarity_score (0-1)
        - match_start_date, match_end_date, match_values, match_dates
        - future_values, future_dates
        - is_self_match, is_cross_category
    """
    # --- 1. Fetch target indicator and its full history ---
    target = db.query(Indicator).filter(Indicator.id == indicator_id).first()
    if not target:
        return []

    target_history = (
        db.query(IndicatorValue)
        .filter(IndicatorValue.indicator_id == indicator_id)
        .order_by(IndicatorValue.recorded_at.asc())
        .all()
    )

    if len(target_history) < query_window_size + 2:
        return []

    target_normed, target_dates, t_min, t_max = _extract_normalized_series(target_history)
    query_window = target_normed[-query_window_size:]
    query_start_idx = len(target_normed) - query_window_size

    # --- 2. Fetch ALL indicators (active only) ---
    all_indicators = (
        db.query(Indicator)
        .filter(Indicator.is_active == True)
        .all()
    )

    # --- 3. Slide window across all indicators ---
    candidates = []

    for ind in all_indicators:
        ind_history = (
            db.query(IndicatorValue)
            .filter(IndicatorValue.indicator_id == ind.id)
            .order_by(IndicatorValue.recorded_at.asc())
            .all()
        )

        if len(ind_history) < query_window_size:
            continue

        ind_normed, ind_dates, _, _ = _extract_normalized_series(ind_history)
        L = len(ind_normed)

        for start in range(0, L - query_window_size + 1):
            # Exclude self-match on the query zone itself
            if ind.id == indicator_id:
                # Skip windows that overlap with the query window's position
                if start >= query_start_idx - 1:  # allow slight overlap for near-matches
                    continue

            window = ind_normed[start:start + query_window_size]
            dist = normalized_dtw_distance(query_window, window, window=query_window_size)

            if dist == float("inf"):
                continue

            candidates.append({
                "indicator_id": ind.id,
                "indicator_name": ind.name,
                "indicator_name_cn": ind.name_cn,
                "category": ind.category,
                "unit": ind.unit,
                "start_idx": start,
                "end_idx": start + query_window_size - 1,
                "distance": round(dist, 6),
                "match_values": [round(v, 4) for v in window],
                "match_dates": ind_dates[start:start + query_window_size],
                # Future segment: what happened after this window
                "future_values": [
                    round(v, 4) for v in ind_normed[start + query_window_size:start + query_window_size + 5]
                ],
                "future_dates": ind_dates[start + query_window_size:start + query_window_size + 5],
                "future_orig_values": [
                    round(h.value, 2) for h in ind_history[start + query_window_size:start + query_window_size + 5]
                ],
                "is_self_match": ind.id == indicator_id,
            })

    # --- 4. Sort by distance, take top K ---
    candidates.sort(key=lambda c: c["distance"])
    top_matches = candidates[:top_k]

    # --- 5. Compute absolute similarity scores ---
    # similarity = 1 / (1 + distance) — gives sensible absolute scale:
    #   distance=0.0 → 1.00 (identical), 0.1 → 0.91, 0.5 → 0.67, 1.0 → 0.50
    for c in top_matches:
        c["similarity_score"] = round(1.0 / (1.0 + c["distance"]), 4)
        c["is_cross_category"] = c["category"] != target.category

    # Filter out near-zero similarity matches (distance too large to be meaningful)
    top_matches = [c for c in top_matches if c["similarity_score"] >= 0.05]

    return top_matches[:top_k]


# ═══════════════════════════════════════════════════════════════════
# Prediction Engine
# ═══════════════════════════════════════════════════════════════════

def compute_predictions(
    db: Session,
    indicator_id: int,
    horizon_years: int = 5,
    top_k: int = 5,
) -> dict:
    """
    Generate prediction corridors based on top analog matches.

    For each future position, aggregates all analogs' "future_values"
    to produce central (median), pessimistic (25th percentile), and
    optimistic (75th percentile) predictions.

    Returns:
        {
            "indicator_id": int,
            "indicator_name_cn": str,
            "unit": str,
            "history": [{date, value}, ...],
            "central": [{date, value}, ...],
            "optimistic": [{date, value}, ...],
            "pessimistic": [{date, value}, ...],
            "analogs_used": [...],
            "confidence": float (avg similarity of top analogs),
            "horizon_years": int,
        }
    """
    target = db.query(Indicator).filter(Indicator.id == indicator_id).first()
    if not target:
        return {}

    target_history = (
        db.query(IndicatorValue)
        .filter(IndicatorValue.indicator_id == indicator_id)
        .order_by(IndicatorValue.recorded_at.asc())
        .all()
    )

    if len(target_history) < 5:
        return {}

    # Get analogs
    analogs = find_analogs(db, indicator_id, query_window_size=6, top_k=top_k)
    if not analogs:
        return {}

    # Determine horizon points
    horizon_points = horizon_years

    # Collect future values from each analog at each position
    future_by_position = {i: [] for i in range(horizon_points)}

    for analog in analogs:
        fv = analog.get("future_values", [])
        for pos, val in enumerate(fv):
            if pos < horizon_points:
                future_by_position[pos].append(val)

    # De-normalization parameters from target's history
    target_normed, target_dates, t_min, t_max = _extract_normalized_series(target_history)
    # Use the last window's min/max for more local de-normalization
    window_size = 6
    recent_vals = [float(h.value) for h in target_history[-window_size:]]
    local_min, local_max = min(recent_vals), max(recent_vals)
    if local_max == local_min:
        local_max = local_min + abs(local_min) * 0.1 + 0.01

    def denorm(nv: float) -> float:
        return round(nv * (local_max - local_min) + local_min, 2)

    # Build prediction arrays
    last_date = target_history[-1].recorded_at
    # Estimate time step from recent data
    if len(target_history) >= 3:
        gaps = []
        for i in range(1, min(6, len(target_history))):
            g = (target_history[-i].recorded_at - target_history[-i-1].recorded_at).days
            if g > 0:
                gaps.append(g)
        avg_gap_days = int(sum(gaps) / len(gaps)) if gaps else 365
    else:
        avg_gap_days = 365

    central = []
    optimistic = []
    pessimistic = []

    for pos in range(horizon_points):
        vals = future_by_position.get(pos, [])
        if not vals:
            continue

        vals_sorted = sorted(vals)
        n = len(vals_sorted)
        median_val = vals_sorted[n // 2] if n > 0 else vals_sorted[0]
        p25_idx = max(0, int(n * 0.25))
        p75_idx = min(n - 1, int(n * 0.75))
        p25_val = vals_sorted[p25_idx] if n > 0 else median_val
        p75_val = vals_sorted[p75_idx] if n > 0 else median_val

        proj_date = last_date + timedelta(days=avg_gap_days * (pos + 1))

        central.append({
            "date": proj_date.strftime("%Y-%m-%d"),
            "value": denorm(median_val),
        })
        optimistic.append({
            "date": proj_date.strftime("%Y-%m-%d"),
            "value": denorm(p75_val),
        })
        pessimistic.append({
            "date": proj_date.strftime("%Y-%m-%d"),
            "value": denorm(p25_val),
        })

    # Ensure pessimist ≤ central ≤ optimistic at each point
    for i in range(len(central)):
        vals = [
            pessimistic[i]["value"],
            central[i]["value"],
            optimistic[i]["value"],
        ]
        vals.sort()
        pessimistic[i]["value"] = vals[0]
        central[i]["value"] = vals[1]
        optimistic[i]["value"] = vals[2]

    # Confidence: average similarity of used analogs
    confidence = round(sum(a.get("similarity_score", 0) for a in analogs) / len(analogs), 4)

    return {
        "indicator_id": indicator_id,
        "indicator_name": target.name,
        "indicator_name_cn": target.name_cn,
        "unit": target.unit,
        "history": [
            {"date": h.recorded_at.strftime("%Y-%m-%d"), "value": round(h.value, 2)}
            for h in target_history
        ],
        "central": central,
        "optimistic": optimistic,
        "pessimistic": pessimistic,
        "analogs_used": [
            {
                "name_cn": a["indicator_name_cn"],
                "category": a["category"],
                "match_dates": f"{a['match_dates'][0]} ~ {a['match_dates'][-1]}",
                "similarity_score": a["similarity_score"],
                "is_self_match": a["is_self_match"],
            }
            for a in analogs
        ],
        "confidence": confidence,
        "horizon_years": horizon_years,
    }


# ═══════════════════════════════════════════════════════════════════
# Civilization Pulse
# ═══════════════════════════════════════════════════════════════════

def get_civilization_pulse(db: Session) -> dict:
    """
    Compute an aggregate "civilization pulse" trend across all indicators.

    All indicators' histories are normalized to [0,1] and averaged on
    a common annual time grid.

    Returns:
        {"dates": [...], "values": [...], "indicator_count": int}
    """
    indicators = (
        db.query(Indicator)
        .filter(Indicator.is_active == True)
        .all()
    )

    # Collect all indicator histories
    all_series = []
    all_years = set()

    for ind in indicators:
        history = (
            db.query(IndicatorValue)
            .filter(IndicatorValue.indicator_id == ind.id)
            .order_by(IndicatorValue.recorded_at.asc())
            .all()
        )
        if len(history) < 5:
            continue

        normed, dates, _, _ = _extract_normalized_series(history)
        years = [h.recorded_at.year for h in history]
        all_years.update(years)
        all_series.append({
            "name_cn": ind.name_cn,
            "category": ind.category,
            "years": years,
            "values": normed,
        })

    if not all_series or not all_years:
        return {"dates": [], "values": [], "indicator_count": 0}

    # Build common grid
    year_min, year_max = min(all_years), max(all_years)
    year_grid = list(range(year_min, year_max + 1))

    # For each year, average all indicators that have data
    avg_values = []
    for yr in year_grid:
        yr_vals = []
        for series in all_series:
            # Find closest year's value
            for i, sy in enumerate(series["years"]):
                if sy == yr:
                    yr_vals.append(series["values"][i])
                    break
                elif sy > yr and i > 0:
                    # Interpolate if we passed the year
                    if series["years"][i - 1] <= yr <= sy:
                        # Use nearest neighbor
                        if yr - series["years"][i - 1] <= sy - yr:
                            yr_vals.append(series["values"][i - 1])
                        else:
                            yr_vals.append(series["values"][i])
                    break
        if yr_vals:
            avg_values.append(round(sum(yr_vals) / len(yr_vals), 4))
        else:
            avg_values.append(None)

    # Fill gaps with interpolation
    for i in range(len(avg_values)):
        if avg_values[i] is None:
            # Find nearest non-None values
            left, right = None, None
            for j in range(i - 1, -1, -1):
                if avg_values[j] is not None:
                    left = avg_values[j]
                    break
            for j in range(i + 1, len(avg_values)):
                if avg_values[j] is not None:
                    right = avg_values[j]
                    break
            if left is not None and right is not None:
                avg_values[i] = round((left + right) / 2, 4)
            elif left is not None:
                avg_values[i] = left
            elif right is not None:
                avg_values[i] = right

    return {
        "dates": [str(y) for y in year_grid],
        "values": avg_values,
        "indicator_count": len(all_series),
    }


# ═══════════════════════════════════════════════════════════════════
# Page Data Assembler
# ═══════════════════════════════════════════════════════════════════

def get_big_history_page_data(db: Session) -> dict:
    """
    Assemble all context needed by the big_history.html template.

    Returns dict with keys:
        indicators, categories, known_analogs, civilization_pulse, default_indicator_id
    """
    indicators = (
        db.query(Indicator)
        .filter(Indicator.is_active == True)
        .order_by(Indicator.importance.desc(), Indicator.category)
        .all()
    )

    # Format for template
    indicator_list = [
        {
            "id": ind.id,
            "name": ind.name,
            "name_cn": ind.name_cn,
            "category": ind.category,
            "category_cn": CATEGORIES.get(ind.category, {}).get("name_cn", ind.category),
            "unit": ind.unit,
            "importance": ind.importance,
            "trend": ind.trend,
            "value": ind.value,
        }
        for ind in indicators
    ]

    # Find default indicator (first with enough history)
    default_id = None
    for ind in indicators:
        count = (
            db.query(IndicatorValue)
            .filter(IndicatorValue.indicator_id == ind.id)
            .count()
        )
        if count >= 8:
            default_id = ind.id
            break

    if default_id is None and indicator_list:
        default_id = indicator_list[0]["id"]

    return {
        "indicators": indicator_list,
        "categories": CATEGORIES,
        "importance_labels": IMPORTANCE,
        "known_analogs": KNOWN_ANALOGS,
        "civilization_pulse": get_civilization_pulse(db),
        "default_indicator_id": default_id,
    }
