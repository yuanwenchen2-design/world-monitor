"""SQLAlchemy ORM models for World Monitor."""

from datetime import datetime, timezone

from sqlalchemy import (
    Column, Integer, String, Float, Text, DateTime, ForeignKey, Boolean
)
from sqlalchemy.orm import relationship

from app.models.database import Base


class Indicator(Base):
    """A tracked world indicator — e.g. US Fed Funds Rate, Global CO2."""

    __tablename__ = "indicators"

    id = Column(Integer, primary_key=True, index=True)
    category = Column(String(32), nullable=False, index=True)   # politics/economy/military/technology/livelihood/composite
    name = Column(String(128), nullable=False)                   # English short name
    name_cn = Column(String(128), nullable=False)                # Chinese display name
    unit = Column(String(32), nullable=False, default="")        # e.g. %, ppm, USD, persons
    value = Column(Float, nullable=True)                         # Current value
    previous_value = Column(Float, nullable=True)                # Previous value (for change calculation)
    change_pct = Column(Float, nullable=True)                    # Percentage change
    trend = Column(String(16), default="stable")                 # up / down / stable
    importance = Column(Integer, default=2)                      # 1-5 energy level
    description = Column(Text, nullable=True)                    # What this indicator means
    source_name = Column(String(128), nullable=True)             # e.g. "Federal Reserve (FRED)"
    source_url = Column(String(512), nullable=True)              # Link to source
    update_frequency = Column(String(32), default="daily")       # daily / weekly / monthly / quarterly / yearly
    last_updated = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)

    # Relationship to history
    history = relationship("IndicatorValue", back_populates="indicator", cascade="all, delete-orphan")


class IndicatorValue(Base):
    """Historical value snapshot for an indicator."""

    __tablename__ = "indicator_values"

    id = Column(Integer, primary_key=True, index=True)
    indicator_id = Column(Integer, ForeignKey("indicators.id"), nullable=False, index=True)
    value = Column(Float, nullable=False)
    recorded_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    indicator = relationship("Indicator", back_populates="history")


class SignalEvent(Base):
    """High-energy world event — geopolitical, economic, technological."""

    __tablename__ = "signal_events"

    id = Column(Integer, primary_key=True, index=True)
    category = Column(String(32), nullable=False, index=True)
    title = Column(String(256), nullable=False)
    title_cn = Column(String(256), nullable=False)
    description = Column(Text, nullable=True)
    importance = Column(Integer, default=3)                      # 1-5
    event_date = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    source_name = Column(String(128), nullable=True)
    source_url = Column(String(512), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
