"""DataUpdater — writes collected values to DB, records history, prevents duplicates."""

from datetime import datetime, timezone, timedelta

from sqlalchemy.orm import Session

from app.collectors.base import CollectResult
from app.models.schema import Indicator, IndicatorValue


class DataUpdater:
    """Handles writing indicator updates to the database.

    - Finds indicator by `name` field
    - Checks for duplicate (same date)
    - Updates value, previous_value, change_pct, trend
    - Appends to IndicatorValue history
    """

    def __init__(self, db: Session):
        self.db = db

    def update_indicator(self, indicator_name: str, new_value: float) -> CollectResult:
        """Update a single indicator's value. Returns CollectResult."""
        indicator = (
            self.db.query(Indicator)
            .filter(Indicator.name == indicator_name)
            .first()
        )

        if not indicator:
            return CollectResult(
                indicator_name=indicator_name,
                status="error",
                error=f"Indicator '{indicator_name}' not found in DB",
            )

        # Check for duplicate: already have a value recorded today?
        today = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
        existing = (
            self.db.query(IndicatorValue)
            .filter(
                IndicatorValue.indicator_id == indicator.id,
                IndicatorValue.recorded_at >= today,
            )
            .first()
        )
        if existing:
            # Update the existing record instead of skipping
            existing.value = new_value
            self.db.commit()
            # Also update the indicator's current value
            indicator.value = new_value
            indicator.last_updated = datetime.now(timezone.utc)
            self.db.commit()
            return CollectResult(
                indicator_name=indicator_name,
                value=new_value,
                previous_value=indicator.previous_value,
                status="skipped",
                error="Already recorded today — value updated in place",
            )

        # Record previous value before updating
        old_value = indicator.value

        # Update indicator
        indicator.previous_value = old_value
        indicator.value = new_value

        # Calculate change
        if old_value is not None and old_value != 0:
            indicator.change_pct = round(
                (new_value - old_value) / abs(old_value) * 100, 2
            )
        else:
            indicator.change_pct = None

        # Determine trend
        if old_value is not None:
            if new_value > old_value:
                indicator.trend = "up"
            elif new_value < old_value:
                indicator.trend = "down"
            else:
                indicator.trend = "stable"

        indicator.last_updated = datetime.now(timezone.utc)

        # Append to history
        history_entry = IndicatorValue(
            indicator_id=indicator.id,
            value=new_value,
            recorded_at=datetime.now(timezone.utc),
        )
        self.db.add(history_entry)
        self.db.commit()

        return CollectResult(
            indicator_name=indicator_name,
            value=new_value,
            previous_value=old_value,
            status="ok",
        )
