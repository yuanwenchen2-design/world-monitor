"""APScheduler setup — schedules periodic data collection."""

import asyncio
import logging
from datetime import datetime, timezone

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from app.models.database import SessionLocal

logger = logging.getLogger("world-monitor.collector")

# Global scheduler instance
scheduler = AsyncIOScheduler()

# Store last collector run status (in-memory)
_collector_status: dict[str, dict] = {}


def get_collector_status() -> dict:
    """Return current collector status for dashboard display."""
    return {
        "collectors": dict(_collector_status),
        "scheduler_running": scheduler.running,
    }


async def run_collector(collector_class):
    """Run a single collector and log results."""
    db = SessionLocal()
    collector_name = collector_class.__name__
    try:
        collector = collector_class()
        report = await collector.collect(db)
        status = f"OK:{report.ok_count}" if report.ok_count else ""
        skip = f"SKIP:{report.skip_count}" if report.skip_count else ""
        err = f"ERR:{report.error_count}" if report.error_count else ""
        parts = [p for p in [status, skip, err] if p]
        msg = f"[Collector] {collector.name}: {' | '.join(parts)}"
        if report.error:
            msg += f" (fetch error: {report.error})"
        logger.info(msg)

        # Store status
        _collector_status[collector_name] = {
            "name": collector.name,
            "last_run": datetime.now(timezone.utc).isoformat(),
            "ok": report.ok_count,
            "skipped": report.skip_count,
            "errors": report.error_count,
            "error_msg": report.error,
            "healthy": report.error_count == 0 and report.error is None,
        }
        return report
    except Exception as e:
        logger.error(f"[Collector] {collector_class.__name__}: {e}")
        _collector_status[collector_name] = {
            "name": getattr(collector_class, 'name', collector_name),
            "last_run": datetime.now(timezone.utc).isoformat(),
            "ok": 0,
            "skipped": 0,
            "errors": 1,
            "error_msg": str(e),
            "healthy": False,
        }
        raise
    finally:
        db.close()


async def collect_all():
    """Run ALL collectors immediately. Used at startup and for manual refresh."""
    from app.collectors.yahoo_finance import YahooFinanceCollector
    from app.collectors.world_bank import WorldBankCollector
    from app.collectors.climate import ClimateCollector

    collectors = [YahooFinanceCollector, WorldBankCollector, ClimateCollector]
    results = []

    for cls in collectors:
        try:
            report = await run_collector(cls)
            results.append(report)
        except Exception as e:
            logger.error(f"[Collector] {cls.__name__} failed completely: {e}")

    total_ok = sum(r.ok_count for r in results)
    logger.info(f"[Collector] All collectors done — {total_ok} indicators updated across {len(results)} collectors")
    return results


def start_scheduler():
    """Start the APScheduler with periodic jobs."""
    from app.collectors.yahoo_finance import YahooFinanceCollector
    from app.collectors.world_bank import WorldBankCollector
    from app.collectors.climate import ClimateCollector

    # Yahoo Finance: weekdays at 08:00 local time
    scheduler.add_job(
        lambda: asyncio.create_task(run_collector(YahooFinanceCollector)),
        CronTrigger(day_of_week="mon-fri", hour=8, minute=0),
        id="yahoo_finance",
        name="Yahoo Finance daily",
        replace_existing=True,
    )

    # World Bank: Mondays at 09:00
    scheduler.add_job(
        lambda: asyncio.create_task(run_collector(WorldBankCollector)),
        CronTrigger(day_of_week="mon", hour=9, minute=0),
        id="world_bank",
        name="World Bank weekly",
        replace_existing=True,
    )

    # Climate: 1st of each month at 10:00
    scheduler.add_job(
        lambda: asyncio.create_task(run_collector(ClimateCollector)),
        CronTrigger(day=1, hour=10, minute=0),
        id="climate",
        name="Climate monthly",
        replace_existing=True,
    )

    scheduler.start()
    logger.info("[Scheduler] Started with 3 periodic jobs")

    # Run all collectors immediately on startup (after a short delay)
    async def initial_collect():
        await asyncio.sleep(2)  # Wait for app to fully start
        logger.info("[Scheduler] Running initial data collection...")
        await collect_all()

    asyncio.create_task(initial_collect())


def stop_scheduler():
    """Shutdown the scheduler gracefully."""
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("[Scheduler] Stopped")
