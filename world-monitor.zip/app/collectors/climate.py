"""Climate data collector — NOAA CO2 and NASA GISTEMP temperature anomaly."""

import logging

import httpx

from app.collectors.base import BaseCollector
from app.config import COLLECTOR_TIMEOUT

logger = logging.getLogger("world-monitor.collector")

# NOAA Mauna Loa CO2 monthly mean data
NOAA_CO2_URL = "https://gml.noaa.gov/webdata/ccgg/trends/co2/co2_mm_mlo.txt"

# NASA GISTEMP v4 global temperature anomaly (land-ocean index)
NASA_GISTEMP_URL = "https://data.giss.nasa.gov/gistemp/tabledata_v4/GLB.Ts+dSST.csv"


class ClimateCollector(BaseCollector):
    """Fetches atmospheric CO2 (NOAA) and global temperature anomaly (NASA GISTEMP).

    Both sources are public, free, and require no API key.
    """

    name = "Climate"

    indicator_map = {
        "co2": "Atmospheric CO2",
        "temperature": "Global Temperature Anomaly",
    }

    async def fetch(self) -> dict[str, float]:
        """Fetch CO2 and temperature anomaly from NOAA/NASA."""
        results = {}

        async with httpx.AsyncClient(timeout=COLLECTOR_TIMEOUT) as client:
            # --- NOAA CO2 ---
            try:
                co2_val = await self._fetch_co2(client)
                if co2_val is not None:
                    results["co2"] = co2_val
            except Exception as e:
                logger.warning(f"NOAA CO2 fetch failed: {e}")

            # --- NASA GISTEMP ---
            try:
                temp_val = await self._fetch_gistemp(client)
                if temp_val is not None:
                    results["temperature"] = temp_val
            except Exception as e:
                logger.warning(f"NASA GISTEMP fetch failed: {e}")

        return results

    async def _fetch_co2(self, client: httpx.AsyncClient) -> float | None:
        """Parse NOAA CO2 monthly mean file, return most recent monthly average."""
        resp = await client.get(NOAA_CO2_URL)
        resp.raise_for_status()
        text = resp.text

        last_avg = None
        for line in text.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 5:
                try:
                    # columns: year month decimal_date average interpolated trend ndays
                    avg = float(parts[3])
                    if avg > 0:  # valid measurement
                        last_avg = avg
                except (ValueError, IndexError):
                    continue

        if last_avg is not None:
            logger.info(f"NOAA CO2 latest monthly average: {last_avg} ppm")
            return round(last_avg, 1)
        return None

    async def _fetch_gistemp(self, client: httpx.AsyncClient) -> float | None:
        """Parse NASA GISTEMP CSV, return most recent annual mean (J-D column)."""
        resp = await client.get(NASA_GISTEMP_URL)
        resp.raise_for_status()
        text = resp.text

        # The CSV has header lines then data. Find the J-D column.
        # Format: Year,Jan,Feb,...,Dec,J-D,D-N,...
        lines = text.splitlines()
        header_idx = None
        jd_col = None

        last_annual_mean = None

        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue

            # Find the header line (starts with "Year")
            if line.startswith("Year") and header_idx is None:
                header_idx = i
                cols = line.split(",")
                for j, col in enumerate(cols):
                    if col.strip() == "J-D":
                        jd_col = j
                        break
                continue

            # Skip until after header
            if header_idx is None or jd_col is None:
                continue
            if i <= header_idx:
                continue

            # Parse data line
            parts = line.split(",")
            if len(parts) > jd_col:
                try:
                    year = int(parts[0].strip())
                    jd_val = parts[jd_col].strip()
                    if jd_val and jd_val not in ("***", "****", ""):
                        val = float(jd_val)
                        # GISTEMP anomaly is in 0.01°C units? No, it's in °C directly.
                        # Values like 1.01 mean 1.01°C above baseline.
                        if abs(val) < 10:  # sanity check
                            last_annual_mean = (year, val)
                except (ValueError, IndexError):
                    continue

        if last_annual_mean is not None:
            year, val = last_annual_mean
            logger.info(f"NASA GISTEMP annual mean {year}: {val}°C")
            return round(val, 2)
        return None
