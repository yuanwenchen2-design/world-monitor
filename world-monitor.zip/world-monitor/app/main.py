"""World Monitor — FastAPI application entry point."""

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from app.config import ON_VERCEL, COLLECTOR_ENABLED
from app.models.database import init_db, SessionLocal
from app.routes import dashboard, api, admin, big_history

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(name)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

logger = logging.getLogger("world-monitor")


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup: init database, seed if empty, start collectors. Shutdown: stop collectors."""
    # Init database tables
    init_db()

    # Seed with initial data if database is empty
    from data.seed_data import seed_database
    db = SessionLocal()
    try:
        result = seed_database(db)
        logger.info(f"Seed: {result}")
    finally:
        db.close()

    # Start data collectors (disabled on Vercel — serverless can't run background tasks)
    if not ON_VERCEL and COLLECTOR_ENABLED:
        from app.collectors.scheduler import start_scheduler, stop_scheduler
        start_scheduler()

    yield

    if not ON_VERCEL and COLLECTOR_ENABLED:
        stop_scheduler()


def create_app() -> FastAPI:
    """Application factory."""
    app = FastAPI(
        title="世界监控室 World Monitor",
        description="Global situation awareness dashboard",
        version="0.1.0",
        lifespan=lifespan,
    )

    # Templates — load from app/templates/
    templates_dir = Path(__file__).parent / "templates"
    templates = Jinja2Templates(directory=str(templates_dir))
    app.state.templates = templates

    # Static files — Vercel CDN handles /static/*, local uses FastAPI mount
    if not ON_VERCEL:
        static_dir = Path(__file__).parent.parent / "static"
        static_dir.mkdir(parents=True, exist_ok=True)
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Register route modules
    app.include_router(dashboard.router, tags=["dashboard"])
    app.include_router(api.router, tags=["api"])
    app.include_router(admin.router, tags=["admin"])
    app.include_router(big_history.router, tags=["big-history"])

    return app


app = create_app()
