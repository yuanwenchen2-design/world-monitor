"""Vercel serverless entry point for World Monitor.

Vercel's Python runtime requires `app` to be a top-level variable.
"""
import os
import sys
from pathlib import Path

# Set environment for Vercel
os.environ["VERCEL"] = "1"

# Add project root to Python path
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    from app.main import app
except Exception as e:
    # Fallback: create a minimal app for debugging
    from fastapi import FastAPI
    app = FastAPI()

    @app.get("/")
    def root():
        return {"error": f"Startup failed: {e}"}

    @app.get("/{path:path}")
    def catch_all(path: str):
        return {"error": f"Startup failed: {e}", "path": path}
